// container.hpp
#pragma once

//---------------------------------- SimplePID ------------------------------------//
class SimplePID {

public:
    SimplePID(double Kp, double Ki, double Kd);
    double calculate(double target, double currentState);

private:
    double m_Kp, m_Ki, m_Kd;
    double m_error = 0;
    double m_pastError = 0;
    double m_integral = 0;

};